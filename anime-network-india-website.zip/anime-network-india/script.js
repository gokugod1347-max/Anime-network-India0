function toggleMenu(){
  document.getElementById("navLinks").classList.toggle("open");
}
document.querySelectorAll("#navLinks a").forEach(a=>{
  a.addEventListener("click",()=>document.getElementById("navLinks").classList.remove("open"));
});

function filterNews(){
  const q=document.getElementById("searchInput").value.toLowerCase().trim();
  document.querySelectorAll(".news-card").forEach(card=>{
    card.style.display=card.dataset.search.includes(q) ? "" : "none";
  });
}

function openNews(title,text){
  document.getElementById("modalTitle").textContent=title;
  document.getElementById("modalText").textContent=text;
  document.getElementById("modal").classList.add("show");
}
function closeModal(e){
  if(!e || e.target.id==="modal") document.getElementById("modal").classList.remove("show");
}
document.addEventListener("keydown",e=>{
  if(e.key==="Escape") document.getElementById("modal").classList.remove("show");
});
document.getElementById("year").textContent=new Date().getFullYear();
