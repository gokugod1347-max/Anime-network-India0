const animeData={
  chitose:{
    title:"Chitose-kun wa Ramune Bin no Naka Part 2",
    img:"chitose.jpg",
    meta:"PG-13 • Not Yet Released • 2026 • feel.",
    tags:["Comedy","Romance"],
    description:"The second part of Chitose-kun wa Ramune Bin no Naka. This page is for release information and anime discovery."
  },
  yasei:{
    title:"Yasei no Last Boss ga Arawareta! 2nd Season",
    img:"yasei.jpg",
    meta:"PG-13 • Not Yet Released • 2026 • WAO World",
    tags:["Action","Adventure","Fantasy"],
    description:"The second season of Yasei no Last Boss ga Arawareta! Follow official announcements and release information here."
  },
  seitokai:{
    title:"Seitokai ni mo Ana wa Aru!",
    img:"seitokai.jpg",
    meta:"Not Yet Released • 2026 • Passione",
    tags:["Comedy","Slice Of Life"],
    description:"Mizunoe Ume joins the student council while trying to deal with his academic problems. This page provides anime information and release updates."
  }
};

function toggleMenu(){document.getElementById("nav").classList.toggle("open")}
function filterAnime(){
  const q=document.getElementById("search").value.toLowerCase().trim();
  let count=0;
  document.querySelectorAll(".searchable").forEach(card=>{
    const ok=card.dataset.title.toLowerCase().includes(q);
    card.style.display=ok?"":"none";
    if(ok)count++;
  });
  document.getElementById("noResults").hidden=count!==0;
}
function openDetails(id){
  const a=animeData[id];
  document.getElementById("detailImg").src=a.img;
  document.getElementById("detailImg").alt=a.title;
  document.getElementById("detailTitle").textContent=a.title;
  document.getElementById("detailMeta").textContent=a.meta;
  document.getElementById("detailDescription").textContent=a.description;
  document.getElementById("detailTags").innerHTML=a.tags.map(t=>`<i>${t}</i>`).join("");
  document.getElementById("episodes").textContent="No playable episodes are hosted here. Official release information will be shown when available.";
  document.getElementById("modal").classList.add("show");
}
function closeModal(e){
  if(!e || e.target.id==="modal")document.getElementById("modal").classList.remove("show");
}
function addLibrary(){alert("Added to your Anime Network India library! 🇮🇳")}
function notifyMe(){alert("Notification preference saved. 🔔")}
async function shareAnime(){
  const title=document.getElementById("detailTitle").textContent;
  if(navigator.share){try{await navigator.share({title,text:title,url:location.href})}catch(e){}}
  else alert("Share this page: "+location.href);
}
function showCategory(name){alert(name+" category selected. Add more anime to this category from your content list.")}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
document.getElementById("year").textContent=new Date().getFullYear();
